/* Service worker: tiene in cache la pagina e il motore per l'uso offline.
   game.pak lo gestisce la pagina (cache separata "openbor-pak-v1"). */
const SHELL = 'openbor-shell-__BUILD__';
const FILES = ['./', 'index.html', 'openbor.js', 'openbor.wasm', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(k => k.startsWith('openbor-shell-') && k !== SHELL).map(k => caches.delete(k))
  )).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.pathname.endsWith('.pak')) return;
  // prima la rete (cosi' ogni nuova compilazione arriva subito), la cache solo offline
  e.respondWith(
    fetch(e.request).then(resp => {
      if (resp.ok) { const copy = resp.clone(); caches.open(SHELL).then(c => c.put(e.request, copy)); }
      return resp;
    }).catch(() => caches.match(e.request, {ignoreSearch: true}))
  );
});
