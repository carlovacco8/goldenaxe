/* Service worker: tiene in cache la pagina e il motore per l'uso offline.
   game.pak lo gestisce la pagina (cache separata "openbor-pak-v1"). */
const SHELL = 'openbor-shell-__BUILD__';
const FILES = ['./', 'index.html', 'openbor.js', 'openbor.wasm', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(k => k.startsWith('openbor-shell-') && k !== SHELL).map(k => caches.delete(k))
  )).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.pathname.endsWith('.pak')) return;
  e.respondWith(
    caches.match(e.request, {ignoreSearch: true}).then(hit => hit || fetch(e.request))
  );
});
