#!/bin/bash
# =====================================================================
#  OpenBOR v4.0 Build 7612 -> WebAssembly (PWA)
#  Gira su GitHub Actions (vedi build.yml)
# =====================================================================
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p build
exec > >(tee build/log-compilazione.txt) 2>&1

echo "== 1/5  Preparo il sorgente OpenBOR"
ZIP=$(ls openbor-*.zip 2>/dev/null | head -n1)
if [ -z "$ZIP" ]; then
  echo "ERRORE: metti lo zip del sorgente OpenBOR (openbor-632699c....zip) in questa cartella."
  exit 1
fi
rm -rf build/src && mkdir -p build/src
python3 -m zipfile -e "$ZIP" build/src/
ENGINE=$(ls -d build/src/openbor-*/engine | head -n1)
cp -r overlay/engine/. "$ENGINE/"
ENGINE_ABS=$(cd "$ENGINE" && pwd)

echo "== 2/5  Preparo le librerie (SDL2, SDL2_gfx, libpng, zlib, ogg, vorbis)"
embuilder build sdl2 sdl2_gfx libpng zlib ogg vorbis || echo "(avviso: embuilder, continuo comunque)"

PORTS="-sUSE_SDL=2 -sUSE_SDL_GFX=2 -sUSE_LIBPNG=1 -sUSE_ZLIB=1 -sUSE_OGG=1 -sUSE_VORBIS=1"
INCS="-I. -Isdl -Isource -Isource/adpcmlib -Isource/gamelib -Isource/preprocessorlib \
-Isource/ramlib -Isource/randlib -Isource/scriptlib -Isource/openborscript -Isource/pnglib -Isource/gfxlib"
CFLAGS="-O3 -std=gnu99 -fsigned-char -w -DLINUX -DSDL=1 -DOV_EXCLUDE_STATIC_CALLBACKS $INCS $PORTS"

SRCS="openbor.c openborscript.c
sdl/joysticks.c sdl/control.c sdl/sblaster.c sdl/timer.c sdl/sdlport.c sdl/video.c sdl/videocommon.c sdl/threads.c sdl/menu.c
source/adpcmlib/adpcm.c
source/gfxlib/2xSaI.c source/gfxlib/bilinear.c source/gfxlib/dotmatrix.c source/gfxlib/gfx.c source/gfxlib/hq2x.c
source/gfxlib/scale2x.c source/gfxlib/scanline.c source/gfxlib/simple2x.c source/gfxlib/tv2x.c
source/gamelib/draw.c source/gamelib/draw16.c source/gamelib/draw32.c source/gamelib/font.c source/gamelib/translation.c
source/gamelib/anigif.c source/gamelib/bitmap.c source/gamelib/screen.c source/gamelib/screen16.c source/gamelib/screen32.c
source/gamelib/loadimg.c source/gamelib/palette.c source/gamelib/packfile.c source/gamelib/filecache.c
source/gamelib/pixelformat.c source/gamelib/soundmix.c source/gamelib/spriteq.c source/gamelib/sprite.c
source/gamelib/spritex8p16.c source/gamelib/spritex8p32.c source/gamelib/models.c source/gamelib/transform.c
source/gamelib/filters.c
source/stringptr.c source/utils.c source/stristr.c source/omath.c
source/scriptlib/StackedSymbolTable.c source/scriptlib/ScriptVariant.c source/scriptlib/SymbolTable.c
source/scriptlib/Instruction.c source/scriptlib/Interpreter.c source/scriptlib/ImportCache.c source/scriptlib/ParserSet.c
source/scriptlib/Parser.c source/scriptlib/Lexer.c source/scriptlib/Stack.c source/scriptlib/List.c
source/preprocessorlib/pp_lexer.c source/preprocessorlib/pp_parser.c source/preprocessorlib/pp_expr.c
source/openborscript/commands.c source/openborscript/animation.c source/openborscript/audio.c source/openborscript/axis.c
source/openborscript/binding.c source/openborscript/drawmethod.c source/openborscript/collision_attack.c
source/openborscript/common_property.c source/openborscript/collision_body.c source/openborscript/collision_entity.c
source/openborscript/colorset.c source/openborscript/constants.c source/openborscript/entity.c source/openborscript/faction.c
source/openborscript/flash.c source/openborscript/global_config.c source/openborscript/icon.c source/openborscript/index.c
source/openborscript/layer.c source/openborscript/level.c source/openborscript/math.c source/openborscript/model.c
source/openborscript/spawn_hud.c source/openborscript/status_dial.c source/openborscript/recursive_damage.c
source/openborscript/string.c
source/ramlib/ram.c source/randlib/rand32.c source/pnglib/pngdec.c source/pnglib/savepng.c"

echo "== 3/5  Compilo il motore ($(echo $SRCS | wc -w) file)"
cd "$ENGINE_ABS"
mkdir -p obj
JOBS=$(nproc 2>/dev/null || echo 4)
FAIL=0
for f in $SRCS; do
  o="obj/$(echo "$f" | tr '/' '_').o"
  ( emcc $CFLAGS -c "$f" -o "$o" || { echo "!! ERRORE in $f"; exit 1; } ) &
  while [ "$(jobs -rp | wc -l)" -ge "$JOBS" ]; do wait -n || FAIL=1; done
done
while [ "$(jobs -rp | wc -l)" -gt 0 ]; do wait -n || FAIL=1; done
wait || FAIL=1
if [ "$FAIL" = "1" ]; then echo "Compilazione fallita: mandami build/log-compilazione.txt"; exit 1; fi

echo "== 4/5  Collego (con ASYNCIFY, può richiedere qualche minuto)"
OUT="$ROOT/sito"
mkdir -p "$OUT"
emcc obj/*.o -O3 $PORTS \
  -sASYNCIFY=1 -sASYNCIFY_STACK_SIZE=262144 \
  -sSTACK_SIZE=8388608 \
  -sINITIAL_MEMORY=134217728 -sALLOW_MEMORY_GROWTH=1 -sMAXIMUM_MEMORY=2147483648 \
  -sFORCE_FILESYSTEM=1 -lidbfs.js \
  -sENVIRONMENT=web -sEXIT_RUNTIME=0 \
  -sEXPORTED_FUNCTIONS=_main,_web_set_touch \
  -sEXPORTED_RUNTIME_METHODS=FS,addRunDependency,removeRunDependency \
  -o "$OUT/openbor.js"

echo "== 5/5  Preparo il sito"
cd "$ROOT"
cp web/index.html web/sw.js web/manifest.webmanifest web/icon-192.png web/icon-512.png "$OUT/"
sed -i "s/__BUILD__/$(date +%Y%m%d%H%M%S)/" "$OUT/sw.js"
PAK=$(ls *.pak 2>/dev/null | head -n1 || true)
if [ -n "$PAK" ]; then
  cp "$PAK" "$OUT/game.pak"
  echo "Copiato $PAK -> sito/game.pak"
else
  echo "NOTA: nessun .pak in questa cartella. Copia il tuo pak in sito/ con il nome game.pak"
fi
echo
echo "FATTO! Cartella pronta: sito/"
ls -la "$OUT"
