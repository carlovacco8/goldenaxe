package com.carlovacco.goldenaxe;

import android.app.Activity;
import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.view.Gravity;
import java.io.File;

import androidx.webkit.WebViewAssetLoader;

/* Golden Axe per Android TV: il gioco gira nella WebView (cartella assets/www),
   i tasti del joypad Bluetooth / telecomando vengono letti qui e passati al motore. */
public class TvActivity extends Activity {
    private WebView web;
    private Updater updater;
    private int keyMask = 0, axisMask = 0, sentMask = -1;

    /* bit del motore: 0 su, 1 giu, 2 sinistra, 3 destra, 4 fendente, 5 magia,
       6 chiama alleato, 7 attacco4, 8 salto, 9 parata, 10 start, 11 menu/esc, 12 menu alleati */
    private static int bitFor(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:    return 1;
            case KeyEvent.KEYCODE_DPAD_DOWN:  return 1 << 1;
            case KeyEvent.KEYCODE_DPAD_LEFT:  return 1 << 2;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 1 << 3;
            case KeyEvent.KEYCODE_BUTTON_A:   return 1 << 4;   // fendente
            case KeyEvent.KEYCODE_BUTTON_X:   return 1 << 5;   // magia
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_BUTTON_C:   return 1 << 8;   // salto
            case KeyEvent.KEYCODE_BUTTON_Y:
            case KeyEvent.KEYCODE_BUTTON_Z:   return 1 << 9;   // parata
            case KeyEvent.KEYCODE_BUTTON_L1:
            case KeyEvent.KEYCODE_BUTTON_L2:  return 1 << 6;   // chiama alleato
            case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_BUTTON_R2:  return 1 << 12;  // menu alleati
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER: return 1 << 10; // start / conferma
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_MODE:  return 1 << 11; // menu
            default: return 0;
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        TextView status = new TextView(this);
        status.setTextColor(0xFFE2B84F);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xE0000000);
        status.setPadding(40, 40, 40, 40);
        status.setVisibility(TextView.GONE);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        web.setFocusable(false);
        setContentView(root);
        hideBars();

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                // gioco aggiornato scaricato dal sito (vedi Updater)
                .addPathHandler("/files/www/", new WebViewAssetLoader.InternalStoragePathHandler(this, new File(getFilesDir(), "www")))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void exit() { runOnUiThread(() -> finish()); }
        }, "AndroidTV");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        updater = new Updater(this, "tv", "tv.html", status, url -> {
            status.postDelayed(() -> status.setVisibility(TextView.GONE), 1200);
            web.loadUrl(url);
        });
        updater.start();
    }

    private void send() {
        int m = keyMask | axisMask;
        if (m == sentMask) return;
        sentMask = m;
        web.evaluateJavascript("window.__tvMask&&__tvMask(" + m + ")", null);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.KEYCODE_BUTTON_SELECT) {      // cambia formato schermo
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0)
                web.evaluateJavascript("window.__tvToggleAspect&&__tvToggleAspect()", null);
            return true;
        }
        int bit = bitFor(code);
        if (bit != 0) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) keyMask |= bit;
            else if (e.getAction() == KeyEvent.ACTION_UP) keyMask &= ~bit;
            send();
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && e.getAction() == MotionEvent.ACTION_MOVE) {
            float x = e.getAxisValue(MotionEvent.AXIS_X), y = e.getAxisValue(MotionEvent.AXIS_Y);
            float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X), hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            int m = 0;
            if (y < -0.5f || hy < -0.5f) m |= 1;
            if (y > 0.5f || hy > 0.5f) m |= 1 << 1;
            if (x < -0.5f || hx < -0.5f) m |= 1 << 2;
            if (x > 0.5f || hx > 0.5f) m |= 1 << 3;
            axisMask = m;
            send();
            return true;
        }
        return super.dispatchGenericMotionEvent(e);
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onPause() {
        keyMask = 0; axisMask = 0; send();
        web.evaluateJavascript("window.__appPause&&__appPause()", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        hideBars();
    }
}
