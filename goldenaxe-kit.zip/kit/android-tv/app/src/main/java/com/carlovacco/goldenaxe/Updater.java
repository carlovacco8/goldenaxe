package com.carlovacco.goldenaxe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/*
 * Aggiornamento automatico del gioco.
 *
 * 1) Il GIOCO (pagina, motore, file .pak) si aggiorna da solo, senza reinstallare l'app:
 *    all'avvio l'app legge version-<tipo>.json dal sito, scarica solo i file cambiati
 *    in una cartella interna e li usa al posto di quelli inclusi nell'APK.
 *    I salvataggi restano, perche' l'indirizzo interno del gioco non cambia.
 * 2) L'APP vera e propria (raro: solo se cambia il codice Java) si aggiorna con un tocco:
 *    l'app scarica il nuovo APK e apre l'installazione di Android. L'APK e' firmato
 *    sempre con la stessa chiave e ha un numero di versione piu' alto, quindi si installa
 *    sopra il vecchio senza "app non installata".
 */
public class Updater {
    public interface Done { void onReady(String startUrl); }

    private static final String HOST = "https://appassets.androidplatform.net";
    private final Activity act;
    private final String flavor;     // "phone" oppure "tv"
    private final String page;       // index.html oppure tv.html
    private final TextView status;
    private final Done done;

    public Updater(Activity act, String flavor, String page, TextView status, Done done) {
        this.act = act; this.flavor = flavor; this.page = page; this.status = status; this.done = done;
    }

    public File wwwDir() { return new File(act.getFilesDir(), "www"); }

    private boolean haveDownloaded() { return new File(wwwDir(), "version.json").exists(); }

    public String localUrl() {
        return haveDownloaded() ? HOST + "/files/www/" + page : HOST + "/assets/www/" + page;
    }

    public void start() {
        new Thread(() -> {
            String url;
            JSONObject remote = null;
            String base = "";
            try {
                base = act.getString(R.string.site_url);
            } catch (Exception ignored) { }
            try {
                if (base.isEmpty()) throw new Exception("nessun sito");
                remote = new JSONObject(getText(base + "version-" + flavor + ".json?t=" + System.currentTimeMillis()));
                updateContent(remote, base);
            } catch (Exception e) {
                // senza internet o con errori: si gioca con quello che c'e' gia'
            }
            url = localUrl();
            final String fUrl = url;
            final JSONObject fRemote = remote;
            final String fBase = base;
            act.runOnUiThread(() -> {
                done.onReady(fUrl);
                if (fRemote != null) checkApk(fRemote, fBase);
            });
        }).start();
    }

    // ------------------------------------------------------------------ gioco
    private JSONObject localManifest() {
        try {
            if (haveDownloaded()) return new JSONObject(readAll(new FileInputStream(new File(wwwDir(), "version.json"))));
            return new JSONObject(readAll(act.getAssets().open("www/version.json")));
        } catch (Exception e) {
            return null;
        }
    }

    private void updateContent(JSONObject remote, String base) throws Exception {
        JSONObject local = localManifest();
        if (local != null && local.optString("build").equals(remote.optString("build"))) return;   // gia' aggiornato

        JSONArray rf = remote.getJSONArray("files");
        long total = 0, done = 0;
        for (int i = 0; i < rf.length(); i++) {
            JSONObject f = rf.getJSONObject(i);
            if (!sameAsLocal(local, f)) total += f.optLong("size");
        }
        File tmp = new File(act.getFilesDir(), "www_new");
        deleteAll(tmp);
        if (!tmp.mkdirs()) throw new Exception("cartella");

        show("Aggiornamento del gioco…");
        for (int i = 0; i < rf.length(); i++) {
            JSONObject f = rf.getJSONObject(i);
            String name = f.getString("name");
            File out = new File(tmp, name);
            if (sameAsLocal(local, f)) {
                // file uguale: lo copio da quello che ho gia' (APK o aggiornamento precedente)
                copy(openLocal(name), new FileOutputStream(out), null, 0, 0);
            } else {
                HttpURLConnection c = (HttpURLConnection) new URL(base + f.getString("url") + "?v=" + f.getString("sha").substring(0, 12)).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(30000);
                if (c.getResponseCode() != 200) throw new Exception("download " + name);
                done = copy(c.getInputStream(), new FileOutputStream(out), "Aggiornamento del gioco… ", done, total);
                c.disconnect();
            }
            if (!sha256(out).equals(f.getString("sha"))) throw new Exception("file rovinato: " + name);
        }
        write(new File(tmp, "version.json"), remote.toString());

        // scambio: il nuovo gioco prende il posto del vecchio solo quando e' completo
        File www = wwwDir();
        File old = new File(act.getFilesDir(), "www_old");
        deleteAll(old);
        if (www.exists() && !www.renameTo(old)) throw new Exception("scambio");
        if (!tmp.renameTo(www)) { old.renameTo(www); throw new Exception("scambio"); }
        deleteAll(old);
        show("Gioco aggiornato!");
    }

    private boolean sameAsLocal(JSONObject local, JSONObject f) {
        if (local == null) return false;
        try {
            JSONArray lf = local.getJSONArray("files");
            for (int i = 0; i < lf.length(); i++) {
                JSONObject l = lf.getJSONObject(i);
                if (l.getString("name").equals(f.getString("name"))) return l.getString("sha").equals(f.getString("sha"));
            }
        } catch (Exception ignored) { }
        return false;
    }

    private InputStream openLocal(String name) throws Exception {
        if (haveDownloaded()) return new FileInputStream(new File(wwwDir(), name));
        return act.getAssets().open("www/" + name);
    }

    // ------------------------------------------------------------------ app (APK)
    private void checkApk(JSONObject remote, String base) {
        try {
            int remoteVer = remote.optInt("apkVersion", 0);
            PackageInfo pi = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
            long myVer = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            if (remoteVer <= myVer) return;
            final String apkUrl = base + remote.optString("apk");
            new AlertDialog.Builder(act)
                .setTitle("Nuova versione dell'app")
                .setMessage("C'e' una nuova versione dell'app Golden Axe. Vuoi installarla adesso? I salvataggi restano.")
                .setPositiveButton("Installa", (d, w) -> downloadApk(apkUrl))
                .setNegativeButton("Piu' tardi", null)
                .show();
        } catch (Exception ignored) { }
    }

    private void downloadApk(String apkUrl) {
        new Thread(() -> {
            try {
                File dir = new File(act.getCacheDir(), "apk");
                dir.mkdirs();
                File apk = new File(dir, "aggiornamento.apk");
                HttpURLConnection c = (HttpURLConnection) new URL(apkUrl + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(30000);
                long len = c.getContentLength();
                copy(c.getInputStream(), new FileOutputStream(apk), "Scarico l'aggiornamento dell'app… ", 0, len);
                c.disconnect();
                act.runOnUiThread(() -> {
                    hide();
                    Uri uri = FileProvider.getUriForFile(act, act.getPackageName() + ".files", apk);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(uri, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                });
            } catch (Exception e) {
                act.runOnUiThread(() -> show("Aggiornamento dell'app non riuscito, riprovero' al prossimo avvio."));
                act.runOnUiThread(() -> status.postDelayed(this::hide, 3000));
            }
        }).start();
    }

    // ------------------------------------------------------------------ utilita'
    private void show(String t) {
        act.runOnUiThread(() -> { status.setText(t); status.setVisibility(TextView.VISIBLE); });
    }

    public void hide() {
        act.runOnUiThread(() -> status.setVisibility(TextView.GONE));
    }

    private static String getText(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(8000);
        c.setUseCaches(false);
        if (c.getResponseCode() != 200) throw new Exception("http " + c.getResponseCode());
        String s = readAll(c.getInputStream());
        c.disconnect();
        return s;
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    private long copy(InputStream in, OutputStream out, String label, long done, long total) throws Exception {
        byte[] buf = new byte[65536];
        int n;
        long lastShown = -1;
        try {
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (label != null && total > 0) {
                    long p = done * 100 / total;
                    if (p != lastShown) { lastShown = p; show(label + p + "%  (" + (done >> 20) + " / " + (total >> 20) + " MB)"); }
                }
            }
        } finally {
            in.close();
            out.close();
        }
        return done;
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        InputStream in = new FileInputStream(f);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        in.close();
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static void write(File f, String s) throws Exception {
        OutputStream o = new FileOutputStream(f);
        o.write(s.getBytes("UTF-8"));
        o.close();
    }

    private static void deleteAll(File f) {
        if (f == null || !f.exists()) return;
        File[] list = f.listFiles();
        if (list != null) for (File c : list) deleteAll(c);
        f.delete();
    }
}
