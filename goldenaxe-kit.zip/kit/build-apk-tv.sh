#!/bin/bash
# APK per Android TV: pagina tv.html + motore + .pak originale (game-orig.pak)
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
W="$ROOT/android-tv/app/src/main/assets/www"
rm -rf "$W" && mkdir -p "$W"
cp "$ROOT/sito/tv.html" "$ROOT/sito/openbor.js" "$ROOT/sito/openbor.wasm" "$ROOT"/sito/flyer-* "$ROOT"/sito/bezel-* "$W/"
if [ -f "$ROOT/game-orig.pak" ]; then cp "$ROOT/game-orig.pak" "$W/game.pak"; else cp "$ROOT/sito/game.pak" "$W/game.pak"; fi
cd "$ROOT/android-tv"
gradle --no-daemon assembleRelease
cp app/build/outputs/apk/release/app-release.apk "$ROOT/sito/goldenaxe-tv.apk"
echo "APK TV pronto: sito/goldenaxe-tv.apk ($(du -h "$ROOT/sito/goldenaxe-tv.apk" | cut -f1))"
