# Scarica il sorgente OpenBOR (commit 632699c) e il .pak dalle Release del repository.
import json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
COMMIT = '632699c9e95cb0bd5c63dbb60245db177e9d41eb'

def download(url, dst, headers=None):
    print('Scarico', url)
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req) as r, open(dst, 'wb') as f:
        while True:
            b = r.read(1 << 20)
            if not b: break
            f.write(b)
    print('  ->', dst, os.path.getsize(dst) // 1048576, 'MB')

# 1) sorgente del motore
src = os.path.join(HERE, 'openbor-%s.zip' % COMMIT)
if not os.path.exists(src):
    download('https://github.com/DCurrent/openbor/archive/%s.zip' % COMMIT, src)

# 2) i giochi (.pak) allegati alle Release
#    - un .pak con "orig" nel nome -> game-orig.pak (originale, per l'APK Android TV)
#    - un altro .pak               -> game.pak      (sito, iPhone, APK telefono)
#    Se ce n'e' uno solo, viene usato per tutto.
repo = os.environ['GITHUB_REPOSITORY']
hdr = {'Accept': 'application/vnd.github+json'}
tok = os.environ.get('GH_TOKEN')
if tok: hdr['Authorization'] = 'Bearer ' + tok
req = urllib.request.Request('https://api.github.com/repos/%s/releases' % repo, headers=hdr)
releases = json.load(urllib.request.urlopen(req))
main_url = orig_url = None
for rel in releases:
    for a in rel.get('assets', []):
        n = a['name'].lower()
        if not n.endswith('.pak'): continue
        if 'orig' in n: orig_url = orig_url or a['browser_download_url']
        else: main_url = main_url or a['browser_download_url']
if not (main_url or orig_url):
    print('ERRORE: non trovo nessun file .pak nelle Release del repository.')
    print('Crea una Release e allega il tuo .pak, poi rilancia il workflow.')
    sys.exit(1)
download(main_url or orig_url, os.path.join(HERE, 'game.pak'))
download(orig_url or main_url, os.path.join(HERE, 'game-orig.pak'))
