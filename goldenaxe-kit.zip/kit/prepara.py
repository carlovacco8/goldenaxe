# Scarica il sorgente OpenBOR (commit 632699c) e il .pak dalle Release del repository.
import json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
COMMIT = '632699c9e95cb0bd5c63dbb60245db177e9d41eb'

def download(url, dst, headers=None):
    print('Scarico', url)
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req) as r, open(dst, 'wb') as f:
        while True:
            b = r.read(1 << 20)
            if not b: break
            f.write(b)
    print('  ->', dst, os.path.getsize(dst) // 1048576, 'MB')

# 1) sorgente del motore
src = os.path.join(HERE, 'openbor-%s.zip' % COMMIT)
if not os.path.exists(src):
    download('https://github.com/DCurrent/openbor/archive/%s.zip' % COMMIT, src)

# 2) il gioco (.pak) caricato come allegato di una Release
if not any(n.lower().endswith('.pak') for n in os.listdir(HERE)):
    repo = os.environ['GITHUB_REPOSITORY']
    hdr = {'Accept': 'application/vnd.github+json'}
    tok = os.environ.get('GH_TOKEN')
    if tok: hdr['Authorization'] = 'Bearer ' + tok
    req = urllib.request.Request('https://api.github.com/repos/%s/releases' % repo, headers=hdr)
    releases = json.load(urllib.request.urlopen(req))
    for rel in releases:
        for a in rel.get('assets', []):
            if a['name'].lower().endswith('.pak'):
                download(a['browser_download_url'], os.path.join(HERE, 'game.pak'))
                sys.exit(0)
    print('ERRORE: non trovo nessun file .pak nelle Release del repository.')
    print('Crea una Release e allega il tuo "My Mod.pak", poi rilancia il workflow.')
    sys.exit(1)
