# Crea sito/version-phone.json e sito/version-tv.json: elenco dei file del gioco con impronta (sha256),
# usato dalle app Android per scaricare solo quello che e' cambiato.
import hashlib, json, os, sys
sito, build = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__))

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()

def entry(name, url):
    p = os.path.join(sito, url)
    return {"name": name, "url": url, "sha": sha(p), "size": os.path.getsize(p)}

def ver(d):
    try: return int(open(os.path.join(here, d, 'versione.txt')).read().strip())
    except Exception: return 1

tv_pak = 'game-orig.pak' if os.path.exists(os.path.join(sito, 'game-orig.pak')) else 'game.pak'
flavors = {
    'phone': {'page': 'index.html', 'apk': 'goldenaxe.apk', 'apkVersion': ver('android'),
              'files': [('index.html', 'index.html'), ('openbor.js', 'openbor.js'), ('openbor.wasm', 'openbor.wasm'),
                        ('game.pak', 'game.pak'), ('icon-192.png', 'icon-192.png'), ('icon-512.png', 'icon-512.png')]},
    'tv':    {'page': 'tv.html', 'apk': 'goldenaxe-tv.apk', 'apkVersion': ver('android-tv'),
              'files': [('tv.html', 'tv.html'), ('openbor.js', 'openbor.js'), ('openbor.wasm', 'openbor.wasm'),
                        ('game.pak', tv_pak), ('flyer-logo.png', 'flyer-logo.png')]},
}
for name, fl in flavors.items():
    files = [entry(n, u) for n, u in fl['files']]
    # la "build" cambia solo se cambia davvero qualche file
    build_id = hashlib.sha256(''.join(f['sha'] for f in files).encode()).hexdigest()[:16]
    data = {"build": build_id, "label": build, "page": fl['page'], "apk": fl['apk'],
            "apkVersion": fl['apkVersion'], "files": files}
    json.dump(data, open(os.path.join(sito, 'version-%s.json' % name), 'w'), indent=1)
    print('version-%s.json: build %s, app v%d' % (name, build_id, fl['apkVersion']))
