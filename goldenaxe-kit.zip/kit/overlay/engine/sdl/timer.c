/*
 * OpenBOR - http://www.chronocrash.com
 * -----------------------------------------------------------------------
 * All rights reserved, see LICENSE in OpenBOR root for details.
 *
 * Copyright (c)  OpenBOR Team
 */

#include <SDL.h>
#include "timer.h"
#include "types.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
/* WEB: il browser deve riprendere il controllo regolarmente,
   altrimenti la pagina si blocca. */
static unsigned web_last_yield = 0;

EM_ASYNC_JS(void, web_wait_animation_frame, (), {
    await new Promise(function(resolve) {
        if (document.hidden) setTimeout(resolve, 50);
        else requestAnimationFrame(function() { resolve(); });
    });
});

/* chiamata dopo ogni fotogramma mostrato: aspetta il vsync del browser */
void web_frame_yield(void)
{
    web_wait_animation_frame();
    web_last_yield = SDL_GetTicks();
}

/* per i cicli che non disegnano nulla (dissolvenze audio, attese) */
void web_yield_if_starving(void)
{
    unsigned now = SDL_GetTicks();
    if(now - web_last_yield > 40)
    {
        emscripten_sleep(0);
        web_last_yield = SDL_GetTicks();
    }
}
#endif

#define GETTIME_FREQ (1000)

static unsigned lastinterval = 0;
static u64 startcounter;
unsigned newticks = 0;

void borTimerInit()
{
	startcounter = SDL_GetPerformanceCounter();
}

void borTimerExit(){}

unsigned timer_getinterval(unsigned freq)
{
	unsigned tickspassed,ebx,blocksize,now;
#ifdef __EMSCRIPTEN__
	web_yield_if_starving();
#endif
	now=SDL_GetTicks()-newticks;
	ebx=now-lastinterval;
	blocksize=GETTIME_FREQ/freq;
	ebx+=GETTIME_FREQ%freq;
	tickspassed=ebx/blocksize;
	ebx-=ebx%blocksize;
	lastinterval+=ebx;
	return tickspassed;
}

unsigned timer_gettick()
{
	return SDL_GetTicks();
}

u64 timer_uticks()
{
	u64 freq = SDL_GetPerformanceFrequency();
	u64 counter = SDL_GetPerformanceCounter();
	return counter * (1000000.0 / freq);
}

unsigned get_last_interval()
{
	return lastinterval;
}

void set_last_interval(unsigned value)
{
	lastinterval = value;
}

void set_ticks(unsigned value)
{
    newticks = value;
}


