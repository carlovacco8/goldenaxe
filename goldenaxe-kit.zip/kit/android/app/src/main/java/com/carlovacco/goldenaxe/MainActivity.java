package com.carlovacco.goldenaxe;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.view.Gravity;
import java.io.File;

import androidx.webkit.WebViewAssetLoader;

/* Apre la versione web del gioco, inclusa nell'APK (cartella assets/www),
   tramite un indirizzo https locale: funziona senza internet. */
public class MainActivity extends Activity {
    private WebView web;
    private Updater updater;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        TextView status = new TextView(this);
        status.setTextColor(0xFFE2B84F);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xE0000000);
        status.setPadding(40, 40, 40, 40);
        status.setVisibility(TextView.GONE);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        hideBars();

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                // gioco aggiornato scaricato dal sito (vedi Updater)
                .addPathHandler("/files/www/", new WebViewAssetLoader.InternalStoragePathHandler(this, new File(getFilesDir(), "www")))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient());

        updater = new Updater(this, "phone", "index.html", status, url -> {
            status.postDelayed(() -> status.setVisibility(TextView.GONE), 1200);
            web.loadUrl(url);
        });
        updater.start();
    }

    private void hideBars() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    /* tasto Indietro = pulsante MENU del gioco */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__androidBack && window.__androidBack()", null);
    }

    @Override
    protected void onPause() {
        web.evaluateJavascript("window.__appPause && window.__appPause()", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        hideBars();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }
}
