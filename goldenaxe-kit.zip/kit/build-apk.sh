#!/bin/bash
# Crea l'APK Android con dentro la versione web gia' compilata (cartella sito/)
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
W="$ROOT/android/app/src/main/assets/www"
rm -rf "$W" && mkdir -p "$W"
cp "$ROOT/sito/index.html" "$ROOT/sito/openbor.js" "$ROOT/sito/openbor.wasm" "$ROOT/sito/game.pak" \
   "$ROOT/sito/icon-192.png" "$ROOT/sito/icon-512.png" "$W/"
cp "$ROOT/sito/version-phone.json" "$W/version.json"
# indirizzo del sito da cui l'app scarica gli aggiornamenti
if [ -n "$GITHUB_REPOSITORY" ]; then
  OWNER=$(echo "${GITHUB_REPOSITORY%%/*}" | tr 'A-Z' 'a-z'); REPO="${GITHUB_REPOSITORY#*/}"
  export SITE_URL="https://$OWNER.github.io/$REPO/"
fi
echo "Aggiornamenti da: ${SITE_URL:-(nessuno)}"
cd "$ROOT/android"
gradle --no-daemon assembleRelease
cp app/build/outputs/apk/release/app-release.apk "$ROOT/sito/goldenaxe.apk"
echo "APK pronto: sito/goldenaxe.apk ($(du -h "$ROOT/sito/goldenaxe.apk" | cut -f1))"

# ---- versione Android TV (joypad, schermo 4:3, flyer, .pak originale) ----
bash "$ROOT/build-apk-tv.sh"
